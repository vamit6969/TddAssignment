package com.assignment.testcases;

import static org.hamcrest.core.IsEqual.equalTo;
import static org.junit.Assert.*;

import org.junit.Test;

import com.assignment.main.Armstrong;

public class ArmstrongTest {

    @Test
    public void check() {
        Armstrong checker = new Armstrong();
        assertThat(checker.check(153), equalTo(true));
        assertThat(checker.check(370), equalTo(true));
        assertThat(checker.check(371), equalTo(true));
        assertThat(checker.check(407), equalTo(true));
        assertThat(checker.check(8208), equalTo(true));
    }
}
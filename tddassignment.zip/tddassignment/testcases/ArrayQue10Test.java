package com.assignment.testcases;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.assignment.main.ArrayQue10;

public class ArrayQue10Test {

	@Test
	public void test1() {
		
		ArrayQue10 arrayclass = new ArrayQue10();
		
		String [] str = {"apple","orange","banana","lemon"};
		
		String expected = "apple-orange-banana-lemon";
		String actual = arrayclass.StringConcate(str);
		
		assertEquals(expected,actual);
	}
	
	
	@Test
	public void test2() {
		
		ArrayQue10 arrayclass = new ArrayQue10();
		
		String [] str = {"APPLE","ORANGE","BANANA","LEMON"};
		
		String expected = "apple-orange-banana-lemon";
		String actual = arrayclass.StringConcate(str);
		
		assertEquals(expected,actual);
	}
	
}

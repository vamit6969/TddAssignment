package com.assignment.testcases;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.assignment.main.Vowels;

public class VowelsTest {
	  @Test
	    public void testCase1() {
	      assertEquals("Nope!", 5, Vowels.getCount("abracadabra"));
	    }
	    
	}
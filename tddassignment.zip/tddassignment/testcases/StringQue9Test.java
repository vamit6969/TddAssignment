package com.assignment.testcases;

import static org.junit.Assert.*;

import org.junit.Test;

import com.assignment.main.StringQue9;

public class StringQue9Test {

	@Test
	public void test1() 
	{
		
	   StringQue9 StringQue9 = new StringQue9();
	   String  str = "This @ Red $car-";
	   String expected = "This Red car";
	   
	   String actual = StringQue9.removeSpecialChar(str);
	   assertEquals(expected, actual);
	}
	
	
	@Test
	public void test2() 
	{
		
	   StringQue9 StringQue9 = new StringQue9();
	   String  str = "This@# 6454 is My** Home%";
	   String expected = "This is My Home";
	   
	   String actual = StringQue9.removeSpecialChar(str);
	   assertEquals(expected, actual);
	}

}
